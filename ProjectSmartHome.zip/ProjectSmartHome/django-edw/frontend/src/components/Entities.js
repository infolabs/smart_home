import BaseEntities from 'components/BaseEntities';


const Entities = BaseEntities;
export default Entities


// import React, { Component } from 'react';
// import BaseEntities from 'components/BaseEntities';
//
//
// export default class Entities extends Component {
//
//     static getTemplates() {
//         return Object.assign(BaseEntities.getTemplates(), {
//             myTemplate1, myTemplate2...
//         });
//     }
//
//     render() {
//         return <BaseEntities {...this.props} getTemplates={Entities.getTemplates}/>
//     }
//
// }
