# -*- coding: utf-8 -*-

from django.contrib import admin

from controller.models import Device


class DeviceAdmin(admin.ModelAdmin):
    model = Device
    list_display = ('__unicode__', 'data', 'actions')


admin.site.register(Device, DeviceAdmin)
