# -*- coding: utf-8 -*-

import os

from django.conf import settings
from django.core.management.base import NoArgsCommand
import requests

from controller.models import Device
from controller.serializers import DeviceSerializer


class Command(NoArgsCommand):
    def handle_noargs(self, **options):
        category_switch = {
            0: 'motionsensor',
            1: 'lightsensor',
            2: 'lightrelay',
        }
        devices_data = []
        for device in Device.objects.all():
            serialized_device = DeviceSerializer(device)
            data = {
                'id': serialized_device.data['code'],
                'name': serialized_device.data['name'],
                'type': category_switch[serialized_device.data['category']],
                'data': serialized_device.data['data'],
            }
            devices_data.append(data)

        result_data = {
            'id': os.environ['CONTROLLER_ID'],
            'url': 'http://{CONTROLLER_HOST}:8000'.format(**os.environ),
            'token': os.environ['CONTROLLER_ACCESS_TOKEN'],
            'devices': devices_data,
        }

        url = 'http://{SERVER_HOST}:8000/api/controller/update/'.format(**os.environ)
        headers = {'Authorization': 'Token {}'.format(os.environ['SERVER_ACCESS_TOKEN'])}
        response = requests.put(url, json=result_data, headers=headers)
