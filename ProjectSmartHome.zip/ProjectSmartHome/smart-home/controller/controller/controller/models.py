# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import json

from django.db import models
from django.utils.translation import ugettext_lazy as _


class Device(models.Model):
    name = models.CharField(
        max_length=255,
        verbose_name=_('Name'),
    )
    code = models.CharField(
        max_length=255,
        verbose_name=_('Code'),
    )
    data = models.TextField(
        verbose_name=_('Data'),
        default='{}'
    )
    actions = models.TextField(
        verbose_name=_('Actions'),
        default='[]',
    )
    CATEGORY_CHOICES = (
        (0, 'Motion sensor'),
        (1, 'Light sensor'),
        (2, 'Light relay'),
    )
    category = models.IntegerField(
        verbose_name=_('Category'),
        choices=CATEGORY_CHOICES,
        default=CATEGORY_CHOICES[0][0],
    )

    class Meta:
        verbose_name = _('Device')
        verbose_name_plural = _('Devices')

    def __unicode__(self):
        return '{} #{} ({})'.format(
            self.get_category_display(),
            self.code,
            self.name,
        )

    @property
    def json_actions(self):
        return json.loads(self.actions)

    @json_actions.setter
    def json_actions(self, value):
        self.actions = value

    @property
    def json_data(self):
        return json.loads(self.data)

    @json_data.setter
    def json_data(self, value):
        self.data = value
