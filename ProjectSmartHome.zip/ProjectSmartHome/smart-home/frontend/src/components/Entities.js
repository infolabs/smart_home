import React, { Component } from 'react';

import BaseEntities from 'components/BaseEntities';
import List from 'components/Entities/List';
import RelationAddList from 'components/Entities/RelationAddList';
import RelationRemoveList from 'components/Entities/RelationRemoveList';


export default class Entities extends Component {

    static getTemplates() {
        return Object.assign(BaseEntities.getTemplates(), {
            "list": List,
            "relation_add_list": RelationAddList,
            "relation_remove_list": RelationRemoveList,
        });
    }

    render() {
        return <BaseEntities {...this.props} getTemplates={Entities.getTemplates}/>
    }
}
