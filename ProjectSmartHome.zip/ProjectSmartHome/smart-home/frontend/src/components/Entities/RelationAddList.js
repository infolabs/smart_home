import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


const TOGGLE_DESCRIPTION_DELAY = 300;

// Container

export default class RelationAddList extends Component {

  render() {
    const { items, actions, loading, descriptions, meta, data_mart } = this.props;
    let entities_class = "entities list-items";
    entities_class = loading ? entities_class + " ex-state-loading" : entities_class;

    return (
      <div className={entities_class}>
        {items.map(
          (child, i) =>
          <RelationAddListItem
              key={i}
              data={child}
              actions={actions}
              loading={loading}
              descriptions={descriptions}
              position={i}
              meta={meta}
              data_mart={data_mart}
          />
        )}
      </div>
    );
  }
}

// Element

class RelationAddListItem extends Component {

  state = {
    minHeight: 0,
    isHover: false
  };

  handleMouseOver(e) {
    this.toggleDescription(e);
  }

  handleMouseOut(e) {
    this.toggleDescription(e);
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.loading !== prevProps.loading) {
      this.setState({minHeight: 'auto'});
    }
  }

  toggleDescription(e) {
    const { data, actions, descriptions } = this.props,
          id = data.id,
          lastIsHover = this.getIsHover(e.clientX, e.clientY);

    this.setState({isHover: lastIsHover});

    let context = this;
    setTimeout(function() {
      const { isHover } = context.state;

      if (lastIsHover === isHover) {
        if (isHover) {
          const area = ReactDOM.findDOMNode(context),
            areaRect = area.getBoundingClientRect();

          context.setState({minHeight: areaRect.height});

          actions.showDescription(id);
          if (!descriptions[id]) {
            actions.getEntityItem(data);
          }
        } else {
          actions.hideDescription(id);
        }
      }
    }, TOGGLE_DESCRIPTION_DELAY);
  }

  getIsHover(clientX, clientY) {
    const area = ReactDOM.findDOMNode(this),
          areaRect = area.getBoundingClientRect(),
          posX = clientX - areaRect.left,
          posY = clientY - areaRect.top;

    return posX >= 0 && posY >= 0 && posX <= areaRect.width && posY <= areaRect.height;
  }

  removeItem = event => {
    const { data, data_mart } = this.props;

    fetch('/api/relations/', {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({'term': 36, 'from_entity': data.id, 'to_entity': parseInt(data_mart.scenario_id)})
    }).then(response => {
      const globalStore = new Singleton();
      for (const alias of Object.keys(globalStore)) {
        reloadDatamart(globalStore[alias]);
      }
    });

    event.preventDefault();
  };

  render() {
    const { data, descriptions, position, meta } = this.props,
        url = data.extra && data.extra.url ? data.extra.url : data.entity_url,
        index = position + meta.offset;

    let item_wrapper_class = "wrap-list-item";
    if (descriptions.opened[data.id]) {
      item_wrapper_class += " is-active";
    }

    return (
      <div className="ex-catalog-item list-item"
         onMouseOver={e => this.handleMouseOver(e)}
         onMouseOut={e => this.handleMouseOut(e)}
         style={{minHeight: this.state.minHeight}}>

        <a href={url} className={item_wrapper_class}>
          <div className="row">
            <div className="col-md-12">
              <h4>{data.entity_name}</h4>
              <object>
                <a href="#" onClick={this.removeItem} title="Добавить">
                  <i className="fa fa-plus" />
                </a>
              </object>
            </div>
          </div>
        </a>
      </div>
    );
  }
}
