# -*- coding: utf-8 -*-

import os

from devices.common import get_state, update_controller, loop


def get_data(day, current_time):
    state = get_state()
    if 'IS_POWER_ON' in os.environ:
        is_power_on = os.environ['IS_POWER_ON']
    else:
        is_power_on = getattr(
            state,
            'LIGHT_RELAY_{NUMBER}_VALUE'.format(**os.environ)
        )
    data = {'power': is_power_on}
    return data


def dispatch_action(action, value):
    if action == 'power':
        os.environ['IS_POWER_ON'] = value


if __name__ == '__main__':
    loop(get_data, dispatch_action, update_controller)
