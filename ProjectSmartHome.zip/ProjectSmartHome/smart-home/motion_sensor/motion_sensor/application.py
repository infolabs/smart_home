# -*- coding: utf-8 -*-

import os

from devices.common import get_state, dispatch_action, update_controller, loop


from datetime import time


# Функция определения движения датчика в комнате
def calculate_motion_sensor_one_value(day, current_time):
    if day == 0:
        if time(hour=9, minute=30) < current_time <= time(hour=10, minute=30):
            return True
        elif time(hour=19, minute=30) < current_time <= time(hour=22, minute=30):
            return True
        else:
            return False
    elif day == 1:
        return False
    elif day == 2:
        if time(hour=6, minute=30) < current_time <= time(hour=10, minute=30):
            return True
        else:
            return False
    else:
        return False


# Функция определения движения датчика на столе
def calculate_motion_sensor_two_value(day, current_time):
    if day == 0:
        if time(hour=19, minute=55) < current_time <= time(hour=20, minute=30):
            return True
        elif time(hour=21, minute=15) < current_time <= time(hour=21, minute=30):
            return True
        else:
            return False
    elif day == 1:
        return False
    elif day == 2:
        if time(hour=6, minute=55) < current_time <= time(hour=10, minute=30):
            return True
        else:
            return False
    else:
        return False


def get_data(day, current_time):
    state = get_state()
    is_motion_detected = getattr(
        state,
        'MOTION_SENSOR_{NUMBER}_VALUE'.format(**os.environ)
    )
    if is_motion_detected is None:
        if os.environ['NUMBER'] == 'ONE':
            is_motion_detected = calculate_motion_sensor_one_value(day, current_time)
        else:
            is_motion_detected = calculate_motion_sensor_two_value(day, current_time)

    data = {'motion': is_motion_detected}
    return data


if __name__ == '__main__':
    loop(get_data, dispatch_action, update_controller)
