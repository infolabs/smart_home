# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models.action.light_sensor import LightSensorAction


class LightSensorActionAdmin(EntityChildModelAdmin):

    base_model = LightSensorAction

    search_fields = ('name',)

    list_display = ['name', 'switch', 'active']

    exclude = ['status', 'get_name', 'get_type']

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'switch', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(LightSensorAction, LightSensorActionAdmin)