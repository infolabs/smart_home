# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from fsm_admin.mixins import FSMTransitionMixin

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models.trigger.light_relay import LightRelayTrigger


class LightRelayTriggerAdmin(FSMTransitionMixin, EntityChildModelAdmin):

    base_model = LightRelayTrigger

    search_fields = ('name',)

    list_display = ['name', 'state_name', 'power', 'active']

    exclude = ['status', 'get_name', 'get_type']

    fsm_field = ['status', ]

    readonly_fields = ['state_name']

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'state_name', 'power', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(LightRelayTrigger, LightRelayTriggerAdmin)