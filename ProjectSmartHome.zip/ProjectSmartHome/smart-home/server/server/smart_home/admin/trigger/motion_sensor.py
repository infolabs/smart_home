# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from fsm_admin.mixins import FSMTransitionMixin

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models.trigger.motion_sensor import MotionSensorTrigger


class MotionSensorTriggerAdmin(FSMTransitionMixin, EntityChildModelAdmin):

    base_model = MotionSensorTrigger

    search_fields = ('name',)

    list_display = ['name', 'state_name', 'motion', 'active']

    exclude = ['status', 'get_name', 'get_type']

    fsm_field = ['status', ]

    readonly_fields = ['state_name']

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'state_name', 'motion', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(MotionSensorTrigger, MotionSensorTriggerAdmin)