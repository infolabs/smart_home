# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import os
import logging
from django.apps import AppConfig
from django.conf import settings
from django.utils.translation import ugettext_lazy as _


class SmartHomeConfig(AppConfig):
    name = 'smart_home'
    verbose_name = _("Smart home")
    logger = logging.getLogger('smart_home')

    def ready(self):
        from smart_home.signals import handlers

        if not os.path.isdir(settings.STATIC_ROOT):
            os.makedirs(settings.STATIC_ROOT)
        if not os.path.isdir(settings.MEDIA_ROOT):
            os.makedirs(settings.MEDIA_ROOT)


class CeleryBeatConfig(AppConfig):
    name = 'django_celery_beat'
    verbose_name = _("Django Celery")
    logger = logging.getLogger('django_celery_beat')


class CeleryResultsConfig(AppConfig):
    name = 'django_celery_results'
    verbose_name = _("Django Celery")
    logger = logging.getLogger('django_celery_results')
