'use strict';

function raiseMessage(form, data, message_class) {
    var message_container = $('[data-message]', form);

    $.each(data, function(key, val) {
        $('.message', message_container).html(val);
        message_container.removeClass();
        message_container.addClass(message_class);
    });
}

function raiseFieldError(form, field_name, error) {
    var form_group = $("[name=" + field_name + "]", form).closest('.form-group');

    form_group.addClass('has-error');
    $('.errors', form_group).html(error);
}

function clearFieldsErrors(form) {
    $.each($('.form-group', form), function () {
        var item = $(this);

        item.removeClass('has-error');
        $('.errors', item).html('');
    })
}

function checkRequiredCheckboxes(form) {
    var result = true;

    $.each($(':checkbox[required=required]', form), function () {
        var item = $(this);

        if (!item.prop( "checked" )) {
            result = false;
            raiseFieldError(form, item.prop('name'), 'Это поле обязательно.')
        }
    });

    return result
}

function scroll_to_error() {
    var first_error = $('.has-error :first');
    $("html, body").animate({ scrollTop: first_error.offset().top }, "slow");
}

function proceedError(form, data, message_class) {
    if (data.responseJSON) {
        $.each(data.responseJSON, function(key, val) {
            if (key == 'non_field_errors' || key == '__all__' || key == 'detail' || key == 'token') {
                raiseMessage(form, {key: val}, message_class)
            }
            else {
                raiseFieldError(form, key, val);
            }
        });
    } else {
        raiseMessage(form, {'error': data.responseText + data.statusText}, message_class)
    }
    scroll_to_error();
}

function hideFormItems(form) {
    $.each($('.btn-block', form), function () {
        var item = $(this);
        item.addClass('hidden');
    });
    $.each($('.form-group', form), function () {
        var item = $(this);
        item.addClass('hidden');
    });
    $.each($('.btn-group', form), function () {
        var item = $(this);
        item.addClass('hidden');
    });
}