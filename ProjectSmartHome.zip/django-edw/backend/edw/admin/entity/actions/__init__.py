#-*- coding: utf-8 -*-
from __future__ import unicode_literals

from update_terms import update_terms
from update_relations import update_relations
# from update_images import update_images
from update_additional_characteristics_or_marks import update_additional_characteristics_or_marks
from update_related_data_marts import update_related_data_marts
from update_states import update_states
from update_active import update_active
from force_validate import force_validate
