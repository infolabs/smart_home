# -*- coding: utf-8 -*-

import json

from rest_framework import serializers

from controller.models import Device


class DeviceSerializer(serializers.ModelSerializer):
    data = serializers.JSONField(source='json_data')
    actions = serializers.ListField(source='json_actions')

    class Meta:
        model = Device
        fields = ('id', 'code', 'name', 'data', 'actions', 'category')
