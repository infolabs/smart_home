# -*- coding: utf-8 -*-

import json

from rest_framework import status
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import SessionAuthentication, TokenAuthentication

from controller.models import Device
from controller.serializers import DeviceSerializer


class DeviceViewSet(viewsets.ModelViewSet):
    authentication_classes = (SessionAuthentication, TokenAuthentication)
    permission_classes = (IsAuthenticated,)
    serializer_class = DeviceSerializer
    queryset = Device.objects.all()
    lookup_field = 'code'

    def partial_update(self, request, *args, **kwargs):
        kwargs['partial'] = True
        response = self.update(request, *args, **kwargs)

        try:
            device = Device.objects.get(code=kwargs['code'])
        except device.DoesNotExist:
            response = Response(
                {'success': False, 'message': 'No such device'},
                status=status.HTTP_404_NOT_FOUND,
            )
        else:
            device.actions = '[]'
            device.save()

        return response


class DispatchActionsView(APIView):
    authentication_classes = (SessionAuthentication, TokenAuthentication)
    permission_classes = (IsAuthenticated,)

    def post(self, request, *args, **kwargs):
        try:
            device = Device.objects.get(code=request.data['device_key'])
        except device.DoesNotExist:
            response = Response(
                {'success': False, 'message': 'No such device'},
                status=status.HTTP_404_NOT_FOUND,
            )
        else:
            # TODO: Переписать с использованием сериалайзера
            actions = json.loads(device.actions)
            actions.extend(json.loads(request.data['actions']))
            device.actions = json.dumps(actions)
            device.save()
            response = Response(
                {'success': True, 'message': 'Ok'},
                status=status.HTTP_200_OK,
            )
        return response
