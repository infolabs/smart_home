# -*- coding: utf-8 -*-

import os
import sys
import json
from time import sleep
from datetime import time, datetime, timedelta

import requests

import state


def get_state():
    return reload(state)


def dispatch_action(action, value):
    pass


def update_controller(data):
    url = 'http://{CONTROLLER_HOST}:8000/api/devices/{DEVICE_ID}/'.format(**os.environ)
    headers = {
        'Authorization': 'Token {}'.format(os.environ['ACCESS_TOKEN']),
        'content-type': 'application/json',
    }
    response = requests.patch(url, json={'data': json.dumps(data)}, headers=headers)
    return response


def loop(get_data, dispatch_action, update_controller):
    state = get_state()

    start = 0
    stop = state.MODELING_PERIOD
    i = start

    while i <= stop:
        current_datetime = state.MODELING_START_DATETIME + timedelta(seconds=i)
        day = i // 86400  # i // 60 * 60 * 24

        is_turned_on = os.environ.get('IS_TURNED_ON', 'on')
        if is_turned_on == 'on':
            data = get_data(day, current_datetime.time())
            data['created_at'] = str(current_datetime)
        else:
            data = previous_data.copy()
        state = get_state()
        try:
            response = update_controller(data)
        except requests.RequestException as exception:
            print exception
        else:
            try:
                response_json = response.json()
            except ValueError as exception:
                print exception
            else:
                if response_json.get('actions'):
                    for action in response_json['actions']:
                        if action['action'] == 'switch':
                            os.environ['IS_TURNED_ON'] = action['value']
                        else:
                            dispatch_action(**action)

                print 'Device {} sends data {}'.format(
                    os.environ['DEVICE_ID'],
                    data,
                )
        finally:
            sys.stdout.flush()
            previous_data = data.copy()
            i += state.POLL_INTERVAL * state.RATE
            sleep(state.POLL_INTERVAL)
