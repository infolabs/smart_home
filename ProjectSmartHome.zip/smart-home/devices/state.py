# -*- coding: utf-8 -*-

from datetime import time, datetime

# Интервал обновления датчиков в секундах:
POLL_INTERVAL = 5
# Ускорение времени в N раз:
RATE = 20
# Период моделирования в секундах:
MODELING_PERIOD = 259200  # 60 * 60 * 24 * 3
# Время и дата начала моделирования:

# MODELING_START_DATETIME = datetime.now()
# можно так указать так, если нужно конкретная дата моделирования
MODELING_START_DATETIME = datetime(day=25, month=1, year=2000, hour=0, minute=0)

# Все три строки взаимоисключающие,
# влияет только последняя раскомментированная.
# Датчик света выдаст текущее время:
# CURRENT_TIME = datetime.now().time()
# Датчик света выдаст указанное время:
# CURRENT_TIME = time(hour=0, minute=0)
# Датчик света выдаст ускоренное текущее время:
CURRENT_TIME = None

# Реле света наверху
LIGHT_RELAY_ONE_VALUE = 'off'
# Реле света на столе
LIGHT_RELAY_TWO_VALUE = 'off'

# Сенсор движения на шкафу
MOTION_SENSOR_ONE_VALUE = None
# Сенсор движения на столе
MOTION_SENSOR_TWO_VALUE = None

RELAY_ON_TABLE_KEY = 'EVEHPEA2'
RELAY_ON_CUPBOARD_KEY = '2TEUZSGW'
