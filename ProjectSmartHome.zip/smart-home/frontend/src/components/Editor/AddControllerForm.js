import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddControllerForm extends Component {

  state = {
    name: '',
    key: ''
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleChangeKey = event => {
    this.setState({key: event.target.value});
  };

  handleSubmit = event => {

    const globalStore = new Singleton(),
        store = globalStore['controllers_datamart'],
        state = store.getState(),
        data_mart_id = state.entities.items.meta.data_mart.id;

    const { name, key } = this.state,
        url = Urls['edw:data-mart-entity-list'](data_mart_id, 'json');

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, key})
    }).then(response => {
        if (response.status >= 400 && response.status <= 417) {
            response.json().then(json => {
                const fields = Object.keys(json);
                if (fields.length) {
                    const errors = json[fields[0]];
                    if (errors.length) {
                        alert(errors.join('; '));
                    } else {
                        console.error('Errors list is empty.');
                    }
                } else {
                    console.error('Fields of the error not found.');
                }
            });
        } else {
            reloadDatamart(store);
        }
    });

    event.preventDefault();
  };

  render() {
    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить контроллер</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="ID контроллера" value={this.state.key} onChange={this.handleChangeKey} required />
              </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
