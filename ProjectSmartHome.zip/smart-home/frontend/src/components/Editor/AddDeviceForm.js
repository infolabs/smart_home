import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddDeviceForm extends Component {

  state = {
    name: '',
    key: '',
    type: 'lightrelay',
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleChangeKey = event => {
    this.setState({key: event.target.value});
  };

  handleChangeType = event => {
    this.setState({type: event.target.value});
  };

  handleSubmit = event => {
    const { name, key, type } = this.state,
        url = Urls['edw:entity-list']('json'),
        controller_id = parseInt(document.getElementById('add-device-form').getAttribute('data-controller-id'));

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, key, controller_id, 'entity_model': type})
    }).then(response => {
      const globalStore = new Singleton();
      reloadDatamart(globalStore['devices_datamart']);
    });

    event.preventDefault();
  };

  render() {
    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить устройство</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="ID устройства" value={this.state.key} onChange={this.handleChangeKey} required />
              </div>

              <div className="form-group has-feedback">
                <select className="form-control" onChange={this.handleChangeType}>
                  <option value="lightrelay">Реле включения света</option>
                  <option value="lightsensor">Датчик света</option>
                  <option value="motionsensor">Датчик движения</option>
                </select>
              </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
