import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddLightRelayTriggerForm extends Component {

  state = {
    name: '',
    power: true
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleSubmit = event => {
    const { name, power } = this.state,
        url = Urls['edw:entity-list']('json'),
        device_id = parseInt(document.getElementById('add-lightrelaytrigger-form').getAttribute('data-device-id'));

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, device_id, power, 'entity_model': 'lightrelaytrigger'})
    }).then(response => {
      const globalStore = new Singleton();
      reloadDatamart(globalStore['triggers_datamart']);
    });

    event.preventDefault();
  };

  render() {
    const { power } = this.state;

    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить триггер включения света</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

                <div className="btn-group">
                  <label className={`btn btn-success ${power ? 'active' : ''}`}>
                      <input type="radio" name="motion"
                             checked={power}
                             onChange={() => this.setState({power: true})} /> Вкл.
                  </label>
                  <label className={`btn btn-danger ${!power ? 'active' : ''}`}>
                    <input type="radio" name="motion"
                           checked={!power}
                           onChange={() => this.setState({power: false})} /> Выкл.
                  </label>
                </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
