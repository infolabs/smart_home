import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddLightSensorActionForm extends Component {

  state = {
    name: '',
    value: true
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleSubmit = event => {
    const { name, value } = this.state,
        url = Urls['edw:entity-list']('json'),
        device_id = parseInt(document.getElementById('add-lightsensoraction-form').getAttribute('data-device-id'));

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, device_id, 'switch': value ? 'on' : 'off', 'entity_model': 'lightsensoraction'})
    }).then(response => {
      const globalStore = new Singleton();
      reloadDatamart(globalStore['actions_datamart']);
    });

    event.preventDefault();
  };

  render() {
    const { value } = this.state;

    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить действие датчика света</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

                <div className="btn-group">
                  <label className={`btn btn-success ${value ? 'active' : ''}`}>
                      <input type="radio" name="motion"
                             checked={value}
                             onChange={() => this.setState({value: true})} /> Вкл.
                  </label>
                  <label className={`btn btn-danger ${!value ? 'active' : ''}`}>
                    <input type="radio" name="motion"
                           checked={!value}
                           onChange={() => this.setState({value: false})} /> Выкл.
                  </label>
                </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
