import React, { Component } from 'react';
import InputRange from 'react-input-range';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';

const MIN_LIMIT = 0,
      MAX_LIMIT = 500;

export default class AddLightSensorTriggerForm extends Component {

  state = {
    name: '',
    value: {
      min: 10,
      max: 200
    },
    inverse: false
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleChangeKey = event => {
    this.setState({key: event.target.value});
  };

  handleChangeInverse = event => {
    this.setState({inverse: event.target.checked});
  };

  handleSubmit = event => {
    const { name, value, inverse } = this.state,
        url = Urls['edw:entity-list']('json'),
        device_id = parseInt(document.getElementById('add-lightsensortrigger-form').getAttribute('data-device-id'));

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, device_id, 'min_luminosity': value.min, 'max_luminosity': value.max, inverse, 'entity_model': 'lightsensortrigger'})
    }).then(response => {
      const globalStore = new Singleton();
      reloadDatamart(globalStore['triggers_datamart']);
    });

    event.preventDefault();
  };

  render() {
    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить триггер датчика света</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

              <p className="text-muted">Пределы освещенности</p>
              <InputRange
                  maxValue={MAX_LIMIT}
                  minValue={MIN_LIMIT}
                  value={this.state.value}
                  onChange={value => this.setState({ value })} />

              <div className="checkbox">
                <label>
                  <input type="checkbox" value={this.state.inverse} onChange={this.handleChangeInverse} /> Инвертировать
                </label>
              </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
