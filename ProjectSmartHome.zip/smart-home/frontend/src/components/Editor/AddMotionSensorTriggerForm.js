import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddMotionSensorTriggerForm extends Component {

  state = {
    name: '',
    motion: true
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleSubmit = event => {
    const { name, motion } = this.state,
        url = Urls['edw:entity-list']('json'),
        device_id = parseInt(document.getElementById('add-motionsensortrigger-form').getAttribute('data-device-id'));

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name, device_id, motion, 'entity_model': 'motionsensortrigger'})
    }).then(response => {
      const globalStore = new Singleton();
      reloadDatamart(globalStore['triggers_datamart']);
    });

    event.preventDefault();
  };

  render() {
    const { motion } = this.state;

    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить триггер датчика движения</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>

                <div className="btn-group">
                  <label className={`btn btn-success ${motion ? 'active' : ''}`}>
                      <input type="radio" name="motion"
                             checked={motion}
                             onChange={() => this.setState({motion: true})} /> Вкл.
                  </label>
                  <label className={`btn btn-danger ${!motion ? 'active' : ''}`}>
                    <input type="radio" name="motion"
                           checked={!motion}
                           onChange={() => this.setState({motion: false})} /> Выкл.
                  </label>
                </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
