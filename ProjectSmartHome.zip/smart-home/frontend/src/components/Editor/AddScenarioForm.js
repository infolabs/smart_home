import React, { Component } from 'react';
import Singleton from 'singleton-js-es6';
import { getCookie, reloadDatamart } from '../utils';


export default class AddScenarioForm extends Component {

  state = {
    name: ''
  };

  handleChangeName = event => {
    this.setState({name: event.target.value});
  };

  handleSubmit = event => {
    const globalStore = new Singleton(),
        store = globalStore['scenarios_datamart'],
        state = store.getState(),
        data_mart_id = state.entities.items.meta.data_mart.id;

    const { name } = this.state,
        url = Urls['edw:data-mart-entity-list'](data_mart_id, 'json');

    fetch(url, {
      credentials: 'include',
      method: 'post',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name})
    }).then(response => {
      reloadDatamart(store);
    });

    event.preventDefault();
  };

  render() {
    return (
      <form className="panel panel-default" onSubmit={this.handleSubmit}>
          <div className="panel-heading">
              <h4>Добавить сценарий</h4>
          </div>
          <div className="panel-body">
              <div className="form-group has-feedback">
                  <input className="form-control" type="text" placeholder="Название" value={this.state.name} onChange={this.handleChangeName} required />
              </div>
          </div>
          <div className="panel-footer">
              <div className="text-center">
                  <input type="submit" className="btn btn-info btn-md btn-block" value="Добавить" />
              </div>
          </div>
      </form>
    );
  }
}
