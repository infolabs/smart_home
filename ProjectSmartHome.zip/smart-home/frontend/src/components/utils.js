export function getCookie(name) {
  let value = "; " + document.cookie;
  let parts = value.split("; " + name + "=");
  if (parts.length === 2) return parts.pop().split(";").shift();
}

export function reloadDatamart(store) {
    const state = store.getState(),
        data_mart_id = state.entities.items.meta.data_mart.id,
        subj_ids = state.entities.items.meta.subj_ids,
        terms_ids = state.entities.items.meta.terms_ids,
        url = Urls['edw:data-mart-entity-by-subject-list'](data_mart_id, subj_ids, 'json') + `?terms=${terms_ids.join(',')}`;

    fetch(url, {
        credentials: 'include',
        method: 'get',
        headers: {
            'X-CSRFToken': getCookie('csrftoken'),
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
    }).then(response => response.json()).then(json => {
        store.dispatch({
            type: 'LOAD_ENTITIES',
            json: json,
            request_options: {}
        });
    });
}
