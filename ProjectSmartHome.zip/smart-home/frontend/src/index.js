import React from 'react';
import { render } from 'react-dom';
import configureStore from 'store/configureStore';
import Root from 'components/Root';


import AddControllerForm from './components/Editor/AddControllerForm';
const add_controller_form = document.getElementById('add-controller-form');
if (add_controller_form) {
    render(<AddControllerForm />, add_controller_form);
}

import AddDeviceForm from './components/Editor/AddDeviceForm';
const add_device_form = document.getElementById('add-device-form');
if (add_device_form) {
    render(<AddDeviceForm />, add_device_form);
}

import AddLightSensorTriggerForm from './components/Editor/AddLightSensorTriggerForm';
const add_lightsensortrigger_form = document.getElementById('add-lightsensortrigger-form');
if (add_lightsensortrigger_form) {
    render(<AddLightSensorTriggerForm />, add_lightsensortrigger_form);
}

import AddLightRelayTriggerForm from './components/Editor/AddLightRelayTriggerForm';
const add_lightrelaytrigger_form = document.getElementById('add-lightrelaytrigger-form');
if (add_lightrelaytrigger_form) {
    render(<AddLightRelayTriggerForm />, add_lightrelaytrigger_form);
}

import AddMotionSensorTriggerForm from './components/Editor/AddMotionSensorTriggerForm';
const add_motionsensortrigger_form = document.getElementById('add-motionsensortrigger-form');
if (add_motionsensortrigger_form) {
    render(<AddMotionSensorTriggerForm />, add_motionsensortrigger_form);
}


import AddMotionSensorActionForm from './components/Editor/AddMotionSensorActionForm';
const add_motionsensoraction_form = document.getElementById('add-motionsensoraction-form');
if (add_motionsensoraction_form) {
    render(<AddMotionSensorActionForm />, add_motionsensoraction_form);
}


import AddLightSensorActionForm from './components/Editor/AddLightSensorActionForm';
const add_lightsensoraction_form = document.getElementById('add-lightsensoraction-form');
if (add_lightsensoraction_form) {
    render(<AddLightSensorActionForm />, add_lightsensoraction_form);
}


import AddLightRelayActionForm from './components/Editor/AddLightRelayActionForm';
const add_lightrelayaction_form = document.getElementById('add-lightrelayaction-form');
if (add_lightrelayaction_form) {
    render(<AddLightRelayActionForm />, add_lightrelayaction_form);
}

import AddScenarioForm from './components/Editor/AddScenarioForm';
const add_scenario_form = document.getElementById('add-scenario-form');
if (add_scenario_form) {
    render(<AddScenarioForm />, add_scenario_form);
}

import Singleton from 'singleton-js-es6';
const globalStore = new Singleton();


const data_marts = document.getElementsByClassName('ex-data-mart');

for (let i = data_marts.length - 1; i >= 0; i--) {
  const data_mart = data_marts[i],
        store = configureStore(),
        dom_attrs = data_mart.attributes;

  let alias = dom_attrs.getNamedItem('data-store-alias');
  if ( !alias ) {
      let mart_id = dom_attrs.getNamedItem('data-selected-entry-point-id').value;
      alias = `data_mart_${mart_id}`
  } else {
      alias = alias.value
  }
  globalStore[alias] = store;

  render(
      <Root store={store} dom_attrs={dom_attrs} />,
      data_mart
  );
}
