# -*- coding: utf-8 -*-

import os
from datetime import time

import requests

from devices.common import get_state, dispatch_action, update_controller, loop


CATEGORY_MOTION_SENSOR = 0
CATEGORY_LIGHT_SENSOR = 1
CATEGORY_LIGHT_RELAY = 2

POSITION_ON_TABLE = 'ON_TABLE'
POSITION_ON_CUPBOARD = 'ON_CUPBOARD'

LUX_PER_MINUTE = 1.6666666666666667
MAXIMUM_LUX_VALUE = 200.0
MINIMUM_LUX_VALUE = 0.1


# Функция определения первичной освещенности комнаты
def calculate_base_light_sensor_value(current_time):
    CONDITION_MORNING = (
        time(hour=6, minute=0) < current_time <= time(hour=8, minute=0)
    )
    CONDITION_DAY = (
        time(hour=8, minute=0) < current_time <= time(hour=20, minute=0)
    )
    CONDITION_EVENING = (
        time(hour=20, minute=0) < current_time <= time(hour=22, minute=0)
    )
    # CONDITION_NIGHT = (
    #     time(hour=22, minute=0) <= current_time <= time(hour=23, minute=59)
    #     or time(hour=0, minute=0) <= current_time <= time(hour=5, minute=59)
    # )
    if CONDITION_MORNING:
        minutes = (current_time.hour - 6) * 60 + current_time.minute
        return round(MINIMUM_LUX_VALUE + (minutes * LUX_PER_MINUTE), 1)
    elif CONDITION_DAY:
        return MAXIMUM_LUX_VALUE
    elif CONDITION_EVENING:
        minutes = (current_time.hour - 20) * 60 + current_time.minute
        return round(MAXIMUM_LUX_VALUE - (minutes * LUX_PER_MINUTE), 1)
    else:
        return MINIMUM_LUX_VALUE


def get_data(day, current_time):
    position = os.environ['SENSOR_POSITION']
    state = get_state()
    # Берем ускоренное время если CURRENT_TIME = None.
    # Если не None, то берем время из этой переменной.
    if state.CURRENT_TIME is not None:
        current_time = state.CURRENT_TIME
    luminosity = calculate_base_light_sensor_value(current_time)

    # Эмуляция добавления освещенности от ламп
    url = 'http://{CONTROLLER_HOST}:8000/api/devices/'.format(**os.environ)
    headers = {'Authorization': 'Token {}'.format(os.environ['ACCESS_TOKEN'])}
    try:
        response = requests.get(url, headers=headers)
    except requests.RequestException as exception:
        print exception
    else:
        try:
            response_json = response.json()
        except ValueError as exception:
            print exception
        else:
            for device in response_json:
                if device.get('category') == CATEGORY_LIGHT_RELAY:
                    data = device['data']
                    if data.get('power') == 'on':
                        if position == POSITION_ON_TABLE:
                            if device['code'] == state.RELAY_ON_TABLE_KEY:
                                luminosity += 140
                            else:
                                luminosity += 55
                        elif position == POSITION_ON_CUPBOARD:
                            if device['code'] == state.RELAY_ON_CUPBOARD_KEY:
                                luminosity += 55
    # Конец эмуляции добавления освещенности от ламп

    data = {'luminosity': luminosity}
    return data


if __name__ == '__main__':
    loop(get_data, dispatch_action, update_controller)
