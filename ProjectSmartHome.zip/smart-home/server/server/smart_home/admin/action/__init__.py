# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from edw.admin.entity import EntityParentModelAdmin

from smart_home.models.action.base_action import BaseAction
from smart_home.models.action.light_sensor import LightSensorAction
from smart_home.models.action.motion_sensor import MotionSensorAction
from smart_home.models.action.light_relay import LightRelayAction


class BaseActionAdmin(EntityParentModelAdmin):

    base_model = BaseAction

    child_models = (
        LightSensorAction,
        MotionSensorAction,
        LightRelayAction
    )

    list_display = ['name', 'get_type', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    search_fields = ('name', )


admin.site.register(BaseAction, BaseActionAdmin)
