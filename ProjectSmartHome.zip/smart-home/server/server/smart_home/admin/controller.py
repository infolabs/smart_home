# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models import Controller


class ControllerAdmin(EntityChildModelAdmin):

    base_model = Controller

    search_fields = ('key', 'name',)

    list_display = ['name', 'key', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'key', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(Controller, ControllerAdmin)
