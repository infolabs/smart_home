# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from smart_home.models.controller_activity import ControllerActivity


class ControllerActivityAdmin(admin.ModelAdmin):
    base_model = ControllerActivity

    readonly_fields = ('updated_at',)
    list_display = ('__unicode__', 'key', 'updated_at')


admin.site.register(ControllerActivity, ControllerActivityAdmin)
