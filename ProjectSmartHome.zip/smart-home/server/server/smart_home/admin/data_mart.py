# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from edw.models.data_mart import DataMartModel
from edw.admin.data_mart import (
    DataMartAdmin as OriginalDataMartAdmin,
    DataMartRelationInline
)


class DataMartAdmin(OriginalDataMartAdmin):

    inlines = [DataMartRelationInline]

admin.site.register(DataMartModel, DataMartAdmin)