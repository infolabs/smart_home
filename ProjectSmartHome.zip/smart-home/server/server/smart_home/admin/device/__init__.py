# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from edw.admin.entity import EntityParentModelAdmin

from smart_home.models.device.base_device import BaseDevice
from smart_home.models.device.light_relay import LightRelay
from smart_home.models.device.light_sensor import LightSensor
from smart_home.models.device.motion_sensor import MotionSensor


class BaseDeviceAdmin(EntityParentModelAdmin):

    base_model = BaseDevice

    child_models = (
        LightRelay,
        LightSensor,
        MotionSensor,
    )

    list_display = ['name', 'get_type', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    search_fields = ('name', )


admin.site.register(BaseDevice, BaseDeviceAdmin)
