# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from smart_home.models.device_log import DeviceLog


class DeviceLogAdmin(admin.ModelAdmin):
    base_model = DeviceLog

    readonly_fields = ('created_at',)
    list_display = ('__unicode__', 'device', 'created_at', 'key', 'value')

    search_fields = ('key', 'value')

    list_filter = ('device', )

admin.site.register(DeviceLog, DeviceLogAdmin)
