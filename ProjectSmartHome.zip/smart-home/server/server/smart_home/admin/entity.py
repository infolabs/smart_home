# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from edw.models.entity import EntityModel
from edw.admin.entity import EntityParentModelAdmin

from smart_home.models import (
    Controller,
    LightSensor,
    LightRelay,
    MotionSensor,
    LightSensorTrigger,
    LightRelayTrigger,
    MotionSensorTrigger,
    Person,
    Scenario,
    LightSensorAction,
    LightRelayAction,
    MotionSensorAction
)

from smart_home.admin.person import PersonrAdmin

from smart_home.admin.controller import ControllerAdmin
from smart_home.admin.scenario import ScenarioAdmin

from smart_home.admin.device.light_sensor import LightSensorAdmin
from smart_home.admin.device.light_relay import LightRelayAdmin
from smart_home.admin.device.motion_sensor import MotionSensorAdmin

from smart_home.admin.trigger.light_sensor import LightSensorTriggerAdmin
from smart_home.admin.trigger.light_relay import LightRelayTriggerAdmin
from smart_home.admin.trigger.motion_sensor import MotionSensorTriggerAdmin

from smart_home.admin.action.light_sensor import LightSensorActionAdmin
from smart_home.admin.action.light_relay import LightRelayActionAdmin
from smart_home.admin.action.motion_sensor import MotionSensorActionAdmin


class EntityAdmin(EntityParentModelAdmin):

    base_model = EntityModel.materialized

    child_models = (
        Person,
        Controller,
        Scenario,
        LightSensor,
        LightRelay,
        MotionSensor,
        LightSensorTrigger,
        LightRelayTrigger,
        MotionSensorTrigger,
        LightSensorAction,
        LightRelayAction,
        MotionSensorAction
    )

    inlines = []
    actions = []

    list_display = ('get_name', 'entity_type', 'active')

    search_fields = ('id', 'controller__name', 'lightsensor__name', 'lightrelay__name', 'motionsensor__name',
                     'controller__key', 'lightsensor__key', 'lightrelay__key', 'motionsensor__key',
                     'lightsensortrigger__name', 'motionsensortrigger__name', 'lightrelaytrigger__name',
                     'lightsensoraction__name', 'motionsensoraction__name', 'lightrelayaction__name',
                     'person__name', 'scenario__name'
                     )

    fieldsets = (
    (None, {
            'fields': ('active', 'terms'),
        }),
    )

admin.site.register(EntityModel, EntityAdmin)
