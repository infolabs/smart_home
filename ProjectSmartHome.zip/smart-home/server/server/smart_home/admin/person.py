# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models import Person


class PersonrAdmin(EntityChildModelAdmin):

    base_model = Person

    search_fields = ('name',)

    list_display = ['name', 'customer', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'customer', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(Person, PersonrAdmin)
