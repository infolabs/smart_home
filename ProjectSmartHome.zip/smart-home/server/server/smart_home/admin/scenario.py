# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from django.utils.translation import ugettext_lazy as _

from edw.admin.entity import (
    EntityChildModelAdmin,
    EntityCharacteristicOrMarkInline,
    EntityRelationInline,
    EntityRelatedDataMartInline,
)

from smart_home.models import Scenario


class ScenarioAdmin(EntityChildModelAdmin):

    base_model = Scenario

    search_fields = ('name',)

    list_display = ['name', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    base_fieldsets = (
        (_("Main params"), {
            'fields': (
                'name', 'active', 'terms', 'created_at'
            ),
        }),
    )

    inlines = [
        EntityCharacteristicOrMarkInline,
        EntityRelationInline,
        EntityRelatedDataMartInline,
    ]

admin.site.register(Scenario, ScenarioAdmin)
