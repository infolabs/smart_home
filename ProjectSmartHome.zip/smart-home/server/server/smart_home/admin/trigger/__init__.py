# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin

from edw.admin.entity import EntityParentModelAdmin

from smart_home.models.trigger.base_trigger import BaseTrigger
from smart_home.models.trigger.light_sensor import LightSensorTrigger
from smart_home.models.trigger.motion_sensor import MotionSensorTrigger
from smart_home.models.trigger.light_relay import LightRelayTrigger


class BaseTriggerAdmin(EntityParentModelAdmin):

    base_model = BaseTrigger

    child_models = (
        LightSensorTrigger,
        MotionSensorTrigger,
        LightRelayTrigger
    )

    list_display = ['name', 'get_type', 'active']

    exclude = ['get_name', 'get_type']

    readonly_fields = ()

    search_fields = ('name', )


admin.site.register(BaseTrigger, BaseTriggerAdmin)
