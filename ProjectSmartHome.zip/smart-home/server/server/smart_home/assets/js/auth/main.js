$(function(){
    'use strict';

    window.captureEvents(Event.KEYPRESS);
    window.onkeypress = function(e) {
        if (e.keyCode === 13) {
            $.each($('[data-edw-auth-form]'), function() {
                var dropdown_cls = $(this).closest('li.dropdown').attr('class');

                if (dropdown_cls) {
                  var cls_arr = dropdown_cls.split(' ');

                  if (cls_arr.indexOf('open') !== -1)
                      $("[data-action-type='send']", $(this)).click();
                }
            });
        }
    };

    function proceedWithAction(data, form, message_class) {
        var action = form.attr('action'),
            next_url = '';

        if (action === 'RELOAD_PAGE') {
            $(location).attr('search').replace(/[?&]+([^=&]+)=([^&]*)/gi, function (str, key, value) {
                if (key == "next") {
                    next_url = value;
                }
            });
            if (next_url == '') {
                window.location.reload(true)
            } else {
                window.location.href = next_url
            }
        } else if (action === 'DO_NOTHING') {
            /* не надо ничего делать, только скроем поля и покажем сообщение об успешности */
            hideFormItems(form);
            raiseMessage(form, data, message_class);
        } else {
            hideFormItems(form);
            raiseMessage(form, data, message_class);
            setTimeout(function (){
                window.location.href = action
            }, 15000);
        }
    }

    $.each($('[data-edw-auth-form]'), function () {
        var edw_auth_form = $(this),
            action = edw_auth_form.attr('action'),
            success_message_class = 'alert alert-success',
            error_message_class = 'alert alert-danger';

        $("[data-action-type='send']", edw_auth_form).click(function(event) {
            var data = edw_auth_form.serialize(),
                form_action_url = $(this).attr('data-action-url');

            event.preventDefault();

            // clear error classes from form groups and clear fields error messages
            $('[data-message]', edw_auth_form).addClass('hidden');
            clearFieldsErrors(edw_auth_form);

            if (checkRequiredCheckboxes(edw_auth_form)) {
                $.ajax({
                    type: "POST",
                    url: form_action_url,
                    data: data,

                    success: function(data) {
                        proceedWithAction(data, edw_auth_form, success_message_class);
                        var registration_footer = $('.registration .panel-footer');
                        if (registration_footer) {
                            registration_footer.addClass('active')
                        }
                    },

                    error: function (data) {
                        if (data.responseJSON) {
                            $.each(data.responseJSON, function(key, val) {
                                if ((key == 'non_field_errors') || (key == '__all__')) {
                                    raiseMessage(edw_auth_form, {key: val}, error_message_class)
                                }
                                else {
                                    raiseFieldError(edw_auth_form, key, val);
                                }
                            });
                        } else {
                            raiseMessage(edw_auth_form, {'error': data.responseText}, error_message_class)
                        }
                    }
                })
            }
        })
    })
});